const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const userRoutes = require('./routes/userRoutes');
const chatRoutes = require('./routes/chatRoutes');
const { PrismaClient } = require('@prisma/client');
const path = require('path');
require('dotenv').config();




const app = express();
const prisma = new PrismaClient();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views')); 
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use((req, res, next) => {
    req.prisma = prisma;
    next();
});


app.set('views', path.join(__dirname, '../views'));

app.use('/users', userRoutes(prisma));
app.use('/chats', chatRoutes(prisma));

app.get('/users', async (req, res) => {
    const users = await prisma.user.findMany();
    res.json(users);
});

app.use('/chats', chatRoutes);

app.get('/', async (req, res) => {
    res.redirect("/chats")
});





app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
