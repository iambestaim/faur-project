exports.listAllChats = async (req, res) => {
  try {
      const chats = await req.prisma.chat.findMany({
          include: {
              sender: true,
              to: true,
          },
      });
      res.render('chat', { chats });
  } catch (error) {
      console.error(error);
      res.status(500).send('Server Error');
  }
};


exports.addChat = async (req, res) => {
  const { content, sender_id, to_id } = req.body;
  const chat = await req.prisma.chat.create({
      data: {
          content,
          sender_id: Number(sender_id),
          to_id: Number(to_id),
      }
  });
  res.json(chat);
};

exports.updateChat = async (req, res) => {
  const { id } = req.params;
  const { content } = req.body;
  const chat = await req.prisma.chat.update({
      where: { id: Number(id) },
      data: { content }
  });
  res.json(chat);
};

exports.deleteChat = async (req, res) => {
  const { id } = req.params;
  const chat = await req.prisma.chat.delete({
      where: { id: Number(id) }
  });
  res.json(chat);
};
