exports.listAllUsers = async (req, res) => {
    const users = await req.prisma.user.findMany();
    res.json(users);
};

exports.addUser = async (req, res) => {
    const { username, password, email, birth_date } = req.body;
    const user = await req.prisma.user.create({
        data: { username, password, email, birth_date: new Date(birth_date) }
    });
    res.json(user);
};

exports.updateUser = async (req, res) => {
    const { id } = req.params;
    const { username, password, email } = req.body;
    const user = await req.prisma.user.update({
        where: { id: Number(id) },
        data: { username, password, email }
    });
    res.json(user);
};

exports.deleteUser = async (req, res) => {
    const { id } = req.params;
    const user = await req.prisma.user.delete({
        where: { id: Number(id) }
    });
    res.json(user);
};
