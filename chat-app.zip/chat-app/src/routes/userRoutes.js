const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

module.exports = (prisma) => {
    router.get('/', userController.listAllUsers);
    router.post('/', userController.addUser);
    router.put('/:id', userController.updateUser);
    router.delete('/:id', userController.deleteUser);
    return router;
};
