const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');

module.exports = router;

module.exports = (prisma) => {
    router.get('/', chatController.listAllChats);
    router.post('/', chatController.addChat);
    router.put('/:id', chatController.updateChat);
    router.delete('/:id', chatController.deleteChat);
    router.get('/chats', chatController.listAllChats);
    return router;
};
